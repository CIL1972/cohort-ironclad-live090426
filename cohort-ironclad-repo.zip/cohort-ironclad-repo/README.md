# -cohort-ironclad-live090426.html

Ironclad — a personal command center for tracking tasks, CRM/leads,
financials, and production across multiple business entities (KRT
Insurance, Eviction Solutions, Collins & Associates, Smack Financial
Literacy, and Personal).

## Files

- `index.html` — the live demo build. Single self-contained file
  (React + all styling inline, no build step). Open it directly in a
  browser, or host it as a static site (e.g. GitHub Pages) and it just
  works.
- `ironclad-app-demo.jsx` — the React source component behind
  `index.html`, kept here for reference/editing.

## ⚠️ Demo data only

This repo intentionally contains **placeholder/fake data only**
(sample leads, no real names or contact info). The real working
version of this app — with actual client data — is kept local and is
never pushed to this or any public repository.

## Data storage

Data is saved to the browser's `localStorage`, scoped per-browser/
per-device. Nothing syncs across devices, and nothing is sent to a
server — nothing about your data leaves the browser you're using.
