import React, { useState, useEffect, useCallback } from "react";

function Icon({ size = 16, color = "currentColor", strokeWidth = 2, style, children }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style}>
      {children}
    </svg>
  );
}
function Shield(props) { return <Icon {...props}><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" /></Icon>; }
function ShieldCheck(props) { return <Icon {...props}><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z" /><path d="M9 12l2 2 4-4" /></Icon>; }
function Home(props) { return <Icon {...props}><path d="M3 11l9-8 9 8" /><path d="M5 10v10h14V10" /></Icon>; }
function Briefcase(props) { return <Icon {...props}><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></Icon>; }
function GraduationCap(props) { return <Icon {...props}><path d="M22 10L12 5 2 10l10 5 10-5z" /><path d="M6 12v5c0 1.5 3 3 6 3s6-1.5 6-3v-5" /></Icon>; }
function User(props) { return <Icon {...props}><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-7 8-7s8 3 8 7" /></Icon>; }
function CheckSquare(props) { return <Icon {...props}><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M8 12l3 3 6-6" /></Icon>; }
function Users(props) { return <Icon {...props}><circle cx="9" cy="8" r="3" /><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6" /><circle cx="17" cy="9" r="2.5" /><path d="M15.5 14c2.5.3 4.5 2.3 4.5 6" /></Icon>; }
function DollarSign(props) { return <Icon {...props}><line x1="12" y1="2" x2="12" y2="22" /><path d="M17 6.5c0-2-2.2-3.5-5-3.5s-5 1.5-5 3.5 2.2 3 5 3.5 5 1.5 5 3.5-2.2 3.5-5 3.5-5-1.5-5-3.5" /></Icon>; }
function Clapperboard(props) { return <Icon {...props}><path d="M3 8l1.5-4h13L19 8" /><rect x="3" y="8" width="18" height="12" rx="1" /><path d="M3 8l16-2" /></Icon>; }
function Inbox(props) { return <Icon {...props}><rect x="3" y="8" width="18" height="12" rx="2" /><path d="M3 12h5l2 3h4l2-3h5" /><path d="M7 8l2-4h6l2 4" /></Icon>; }
function Receipt(props) { return <Icon {...props}><path d="M6 2h12v20l-3-2-3 2-3-2-3 2V2z" /><line x1="9" y1="7" x2="15" y2="7" /><line x1="9" y1="11" x2="15" y2="11" /><line x1="9" y1="15" x2="13" y2="15" /></Icon>; }
function Film(props) { return <Icon {...props}><rect x="3" y="4" width="18" height="16" rx="2" /><line x1="7" y1="4" x2="7" y2="20" /><line x1="17" y1="4" x2="17" y2="20" /><line x1="3" y1="9" x2="7" y2="9" /><line x1="3" y1="15" x2="7" y2="15" /><line x1="17" y1="9" x2="21" y2="9" /><line x1="17" y1="15" x2="21" y2="15" /></Icon>; }

const ENTITIES = [
  { id: "krt", name: "KRT Insurance", short: "KRT", color: "#4A7FA6", Icon: Shield },
  { id: "eviction", name: "Eviction Solutions", short: "Eviction", color: "#B5654F", Icon: Home },
  { id: "collins", name: "Collins & Associates", short: "Collins", color: "#5C8A6C", Icon: Briefcase },
  { id: "smack", name: "Smack Financial Literacy", short: "Smack", color: "#C9A227", Icon: GraduationCap },
  { id: "personal", name: "Personal", short: "Personal", color: "#8A8B87", Icon: User },
];

const CRM_ENTITIES = ENTITIES.filter((e) => e.id !== "personal");

const PRIORITIES = [
  { id: "high", label: "High" },
  { id: "med", label: "Med" },
  { id: "low", label: "Low" },
];

const STAGES = [
  { id: "new", label: "New", color: "#8A8B87" },
  { id: "contacted", label: "Contacted", color: "#4A7FA6" },
  { id: "qualified", label: "Qualified", color: "#C9A227" },
  { id: "proposal", label: "Proposal", color: "#B5654F" },
  { id: "won", label: "Won", color: "#5C8A6C" },
  { id: "lost", label: "Lost", color: "#6B6D68" },
];

const SCENE_STATUSES = [
  { id: "outline", label: "Outlined", color: "#8A8B87" },
  { id: "draft", label: "Drafted", color: "#4A7FA6" },
  { id: "revised", label: "Revised", color: "#C9A227" },
  { id: "locked", label: "Locked", color: "#5C8A6C" },
  { id: "shot", label: "Shot", color: "#B08D57" },
];

const MODULES = [
  { id: "tasks", label: "Tasks", Icon: CheckSquare },
  { id: "crm", label: "CRM", Icon: Users },
  { id: "financials", label: "Financials", Icon: DollarSign },
  { id: "turnaround", label: "Turnaround", Icon: Clapperboard },
];


function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date(todayISO() + "T00:00:00");
  const due = new Date(dateStr + "T00:00:00");
  return Math.round((due - today) / 86400000);
}
function dueLabel(dateStr, pastLabel) {
  if (!dateStr) return { text: "No date", tone: "muted" };
  const diff = daysUntil(dateStr);
  const formatted = new Date(dateStr + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" });
  if (diff < 0) return { text: `${formatted} · ${Math.abs(diff)}d ${pastLabel || "overdue"}`, tone: "overdue" };
  if (diff === 0) return { text: `${formatted} · today`, tone: "today" };
  if (diff === 1) return { text: `${formatted} · tomorrow`, tone: "soon" };
  if (diff <= 7) return { text: `${formatted} · ${diff}d`, tone: "soon" };
  return { text: formatted, tone: "normal" };
}
function toneColor(tone) {
  switch (tone) {
    case "overdue":
      return "#D9776A";
    case "today":
      return "#D9A24B";
    case "soon":
      return "#C9A227";
    case "muted":
      return "#A8987A";
    default:
      return "#8A7A5C";
  }
}
function money(n) {
  const v = Number(n) || 0;
  return v.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
}

function parseCsvLine(line) {
  const result = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (line[i + 1] === '"') {
          cur += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cur += ch;
      }
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      result.push(cur.trim());
      cur = "";
    } else {
      cur += ch;
    }
  }
  result.push(cur.trim());
  return result;
}

function bulkParseText(text, fieldDefs) {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];
  const keys = fieldDefs.map((f) => f.key.toLowerCase());
  const firstRow = parseCsvLine(lines[0]).map((c) => c.toLowerCase());
  const isHeader = firstRow.length > 1 && firstRow.every((c) => keys.includes(c));
  const dataLines = isHeader ? lines.slice(1) : lines;
  return dataLines.map((line) => {
    const cells = parseCsvLine(line);
    const obj = {};
    if (isHeader) {
      firstRow.forEach((key, idx) => {
        obj[key] = cells[idx] || "";
      });
    } else {
      fieldDefs.forEach((f, idx) => {
        obj[f.key] = cells[idx] || "";
      });
    }
    return obj;
  });
}

function BulkAddPanel({ fields, example, itemLabel, accentColor, onAdd }) {
  const [text, setText] = useState("");
  const [feedback, setFeedback] = useState("");

  function handleAdd() {
    if (!text.trim()) return;
    const rows = bulkParseText(text, fields);
    const requiredKeys = fields.filter((f) => f.required).map((f) => f.key);
    const valid = rows.filter((r) => requiredKeys.every((k) => (r[k] || "").trim().length > 0));
    if (valid.length === 0) {
      setFeedback("No valid rows found — check that required fields are filled in.");
      return;
    }
    onAdd(valid);
    const skipped = rows.length - valid.length;
    setFeedback(`Added ${valid.length} ${itemLabel}${valid.length === 1 ? "" : "s"}${skipped ? ` (skipped ${skipped} incomplete row${skipped === 1 ? "" : "s"})` : ""}.`);
    setText("");
  }

  return (
    <div style={styles.form}>
      <div style={styles.bulkHint}>
        Paste one {itemLabel} per line: {fields.map((f) => f.label).join(", ")} — comma-separated. Or paste CSV with a header row using those field names.
        <div style={styles.bulkExample}>{example}</div>
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={`Paste ${itemLabel} data here, one per line...`}
        style={{ ...styles.input, minHeight: 120, resize: "vertical", fontFamily: "'JetBrains Mono', monospace", fontSize: 12 }}
      />
      <button type="button" className="ic-btn" style={{ ...styles.saveBtn, background: accentColor }} onClick={handleAdd}>
        Add all
      </button>
      {feedback && <div style={styles.bulkFeedback}>{feedback}</div>}
    </div>
  );
}

const TASK_CATEGORIES = [
  { id: "intake", label: "New Client Intake", color: "#4A7FA6" },
  { id: "entity", label: "Business Entity Startup", color: "#5C8A6C" },
  { id: "other", label: "Other Tasks", color: "#8A8B87" },
];

const CHECKLIST_ITEMS = [
  // New Client Intake
  { category: "intake", subsection: "First Contact", title: "Log inquiry source (referral, ad, walk-in, website, etc.)" },
  { category: "intake", subsection: "First Contact", title: "Capture name, phone, email, and preferred contact method" },
  { category: "intake", subsection: "First Contact", title: "Note the service/product they're interested in" },
  { category: "intake", subsection: "First Contact", title: "Schedule intake call or meeting" },
  { category: "intake", subsection: "Qualification", title: "Confirm eligibility (location, budget, timeline, needs match)" },
  { category: "intake", subsection: "Qualification", title: "Identify decision-maker(s) if not the contact themselves" },
  { category: "intake", subsection: "Qualification", title: "Flag any red flags or special circumstances early" },
  { category: "intake", subsection: "Qualification", title: "Determine urgency / target start date" },
  { category: "intake", subsection: "Documentation & Compliance", title: "Collect required ID / legal documents" },
  { category: "intake", subsection: "Documentation & Compliance", title: "Send and receive signed engagement letter or service agreement" },
  { category: "intake", subsection: "Documentation & Compliance", title: "Complete any required disclosures or compliance forms" },
  { category: "intake", subsection: "Documentation & Compliance", title: "Run conflict-of-interest or background check (if applicable)" },
  { category: "intake", subsection: "Documentation & Compliance", title: "Store documents in client file / CRM record" },
  { category: "intake", subsection: "Financial Setup", title: "Confirm pricing, retainer, or premium quote" },
  { category: "intake", subsection: "Financial Setup", title: "Set up billing/payment method" },
  { category: "intake", subsection: "Financial Setup", title: "Record initial payment or deposit received" },
  { category: "intake", subsection: "Financial Setup", title: "Enter client into invoicing/accounting system" },
  { category: "intake", subsection: "Internal Handoff", title: "Create client record in CRM" },
  { category: "intake", subsection: "Internal Handoff", title: "Assign account owner / case manager" },
  { category: "intake", subsection: "Internal Handoff", title: "Brief relevant team members on client needs" },
  { category: "intake", subsection: "Internal Handoff", title: "Set follow-up tasks and next milestone dates" },
  { category: "intake", subsection: "Client Communication", title: "Send welcome email/packet with next steps" },
  { category: "intake", subsection: "Client Communication", title: "Share timeline and what to expect" },
  { category: "intake", subsection: "Client Communication", title: "Confirm preferred communication cadence" },
  { category: "intake", subsection: "Client Communication", title: "Add first check-in to calendar" },
  // Business Entity Startup
  { category: "entity", subsection: "Foundation", title: "Choose business name and check availability" },
  { category: "entity", subsection: "Foundation", title: "Decide entity type (LLC, S-corp, C-corp, partnership, sole prop)" },
  { category: "entity", subsection: "Foundation", title: "Draft mission/purpose statement and initial business plan" },
  { category: "entity", subsection: "Foundation", title: "Identify owners/members and ownership percentages" },
  { category: "entity", subsection: "Legal Formation", title: "File formation documents with Secretary of State" },
  { category: "entity", subsection: "Legal Formation", title: "Draft and sign Operating Agreement / Bylaws" },
  { category: "entity", subsection: "Legal Formation", title: "Appoint registered agent" },
  { category: "entity", subsection: "Legal Formation", title: "Obtain EIN from IRS" },
  { category: "entity", subsection: "Legal Formation", title: "Apply for required state/local business licenses or permits" },
  { category: "entity", subsection: "Financial Setup", title: "Open business bank account" },
  { category: "entity", subsection: "Financial Setup", title: "Set up bookkeeping/accounting system" },
  { category: "entity", subsection: "Financial Setup", title: "Apply for business credit card (if needed)" },
  { category: "entity", subsection: "Financial Setup", title: "Set up payroll system (if hiring employees)" },
  { category: "entity", subsection: "Financial Setup", title: "Determine tax filing requirements and register with state tax agency" },
  { category: "entity", subsection: "Insurance & Risk", title: "Obtain general liability insurance" },
  { category: "entity", subsection: "Insurance & Risk", title: "Obtain professional liability/E&O insurance (if applicable)" },
  { category: "entity", subsection: "Insurance & Risk", title: "Obtain workers' comp insurance (if hiring)" },
  { category: "entity", subsection: "Insurance & Risk", title: "Review contracts for liability exposure" },
  { category: "entity", subsection: "Operations", title: "Set up business address (physical or virtual)" },
  { category: "entity", subsection: "Operations", title: "Set up phone, email, and domain" },
  { category: "entity", subsection: "Operations", title: "Choose and configure CRM / project management tools" },
  { category: "entity", subsection: "Operations", title: "Set up contracts, invoices, and standard document templates" },
  { category: "entity", subsection: "Operations", title: "Establish standard operating procedures (SOPs)" },
  { category: "entity", subsection: "Brand & Marketing", title: "Design logo and brand guidelines" },
  { category: "entity", subsection: "Brand & Marketing", title: "Build website / landing page" },
  { category: "entity", subsection: "Brand & Marketing", title: "Set up social media profiles" },
  { category: "entity", subsection: "Brand & Marketing", title: "Create marketing materials (business cards, one-pagers)" },
  { category: "entity", subsection: "Compliance & Ongoing", title: "Note annual report / renewal deadlines" },
  { category: "entity", subsection: "Compliance & Ongoing", title: "Set calendar reminders for tax deadlines" },
  { category: "entity", subsection: "Compliance & Ongoing", title: "Schedule periodic legal/compliance review" },
  { category: "entity", subsection: "Compliance & Ongoing", title: "Set up recordkeeping system for corporate documents" },
];

function buildSeedTasks() {
  const seeded = [];
  ENTITIES.forEach((entity) => {
    CHECKLIST_ITEMS.forEach((item) => {
      seeded.push({
        id: uid(),
        entityId: entity.id,
        category: item.category,
        title: item.title,
        dueDate: null,
        priority: "med",
        notes: item.subsection,
        status: "open",
        createdAt: todayISO(),
      });
    });
  });
  return seeded;
}

const KRT_LEAD_SEED = [
  {
    name: "Sample Lead A",
    phone: "(555) 010-1001",
    notes: "Demo data — Age 59. Spouse: Sample Spouse A. Final expense mailer response.",
  },
  {
    name: "Sample Lead B",
    phone: "(555) 010-1002",
    notes: "Demo data — Age 82. Final expense mailer response.",
  },
  {
    name: "Sample Lead C",
    phone: "(555) 010-1003",
    notes: "Demo data — Age 69. Final expense mailer response.",
  },
  {
    name: "Sample Lead D",
    phone: "(555) 010-1004",
    notes: "Demo data — Age 73. Spouse: Sample Spouse D. Final expense mailer response.",
  },
  {
    name: "Sample Lead E",
    phone: "(555) 010-1005",
    notes: "Demo data — Age 65. Final expense mailer response.",
  },
  {
    name: "Sample Lead F",
    phone: "(555) 010-1006",
    notes: "Demo data — Age 65. Spouse: Sample Spouse F. Final expense mailer response.",
  },
];

function buildSeedContacts() {
  return KRT_LEAD_SEED.map((lead) => ({
    id: uid(),
    entityId: "krt",
    name: lead.name,
    company: "",
    phone: lead.phone,
    email: "",
    value: "",
    stage: "new",
    nextFollowUp: "",
    notes: lead.notes,
    createdAt: todayISO(),
  }));
}

async function loadKey(key, fallback) {
  try {
    const result = await window.storage.get(key, false);
    return result ? JSON.parse(result.value) : fallback;
  } catch {
    return fallback;
  }
}
async function saveKey(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value), false);
    return true;
  } catch {
    return false;
  }
}

export default function IroncladApp() {
  const [activeModule, setActiveModule] = useState("tasks");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [tasks, setTasks] = useState(null);
  const [contacts, setContacts] = useState(null);
  const [entries, setEntries] = useState(null);
  const [scenes, setScenes] = useState(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [t, c, e, s] = await Promise.all([
        loadKey("ironclad-demo-tasks-v1", null),
        loadKey("ironclad-demo-crm-v1", null),
        loadKey("ironclad-demo-financials-v1", []),
        loadKey("ironclad-demo-turnaround-v1", []),
      ]);
      if (!cancelled) {
        setTasks(t !== null ? t : buildSeedTasks());
        setContacts(c !== null ? c : buildSeedContacts());
        setEntries(e);
        setScenes(s);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const persist = useCallback(async (key, value) => {
    setSaving(true);
    const ok = await saveKey(key, value);
    if (!ok) setError("Couldn't save — your changes may not persist.");
    setSaving(false);
  }, []);

  function updateTasks(next) {
    setTasks(next);
    persist("ironclad-demo-tasks-v1", next);
  }
  function updateContacts(next) {
    setContacts(next);
    persist("ironclad-demo-crm-v1", next);
  }
  function updateEntries(next) {
    setEntries(next);
    persist("ironclad-demo-financials-v1", next);
  }
  function updateScenes(next) {
    setScenes(next);
    persist("ironclad-demo-turnaround-v1", next);
  }

  const loaded = tasks !== null && contacts !== null && entries !== null && scenes !== null;

  return (
    <div style={styles.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; }
        .ic-btn { transition: opacity 0.12s ease, transform 0.08s ease; }
        .ic-btn:active { transform: scale(0.97); }
        .ic-tab { transition: background 0.12s ease, opacity 0.12s ease; }
        .ic-row { transition: background 0.1s ease; }
        .ic-row:hover { background: #F1E7CE; }
        .ic-mod { transition: color 0.12s ease, border-color 0.12s ease; }
        input, textarea, select { font-family: 'Inter', sans-serif; }
        ::placeholder { color: #B5AB94; }
      `}</style>

      <header style={styles.header}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <ShieldCheck size={26} color="#B08D57" strokeWidth={2} />
          <div>
            <div style={styles.wordmark}>IRONCLAD</div>
            <div style={styles.subtitle}>Command center · Demo data</div>
          </div>
        </div>
        <nav style={styles.moduleNav}>
          {MODULES.map((m) => (
            <button
              key={m.id}
              className="ic-mod"
              onClick={() => setActiveModule(m.id)}
              style={{
                ...styles.moduleBtn,
                color: activeModule === m.id ? "#3A2F1E" : "#8A7A5C",
                borderBottom: activeModule === m.id ? "2px solid #B08D57" : "2px solid transparent",
              }}
            >
              <m.Icon size={14} style={{ marginRight: 6, verticalAlign: -2 }} />
              {m.label}
            </button>
          ))}
        </nav>
      </header>

      {!loaded ? (
        <div style={{ padding: 40, textAlign: "center", color: "#8A7A5C", fontSize: 14 }}>Loading your data…</div>
      ) : (
        <>
          {activeModule === "tasks" && <TasksModule tasks={tasks} updateTasks={updateTasks} />}
          {activeModule === "crm" && <CRMModule contacts={contacts} updateContacts={updateContacts} />}
          {activeModule === "financials" && <FinancialsModule entries={entries} updateEntries={updateEntries} />}
          {activeModule === "turnaround" && <TurnaroundModule scenes={scenes} updateScenes={updateScenes} />}
        </>
      )}

      <footer style={styles.footer}>
        {saving ? "Saving…" : "Saved locally to this app"}
        {error && <span style={{ color: "#B5453A", marginLeft: 10 }}>{error}</span>}
      </footer>
    </div>
  );
}

function EntityTabs({ entities, active, onChange, counts }) {
  return (
    <nav style={styles.tabRow}>
      {entities.map((e) => {
        const activeTab = e.id === active;
        return (
          <button
            key={e.id}
            className="ic-tab"
            onClick={() => onChange(e.id)}
            style={{
              ...styles.tab,
              borderTop: `3px solid ${e.color}`,
              background: activeTab ? "#FFFCF3" : "#F1E7CE",
              opacity: activeTab ? 1 : 0.65,
              color: activeTab ? "#3A2F1E" : "#8A7A5C",
            }}
          >
            <e.Icon size={14} color={e.color} style={{ marginRight: 2 }} />
            {e.short}
            {counts && <span style={{ ...styles.tabCount, color: activeTab ? e.color : "#A8987A" }}>{counts[e.id] || 0}</span>}
          </button>
        );
      })}
    </nav>
  );
}

function Stat({ label, value, tone }) {
  return (
    <div style={styles.stat}>
      <div style={{ ...styles.statValue, color: toneColor(tone) }}>{value}</div>
      <div style={styles.statLabel}>{label}</div>
    </div>
  );
}

function TasksModule({ tasks, updateTasks }) {
  const [activeEntity, setActiveEntity] = useState("krt");
  const [showDone, setShowDone] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [form, setForm] = useState({ title: "", dueDate: "", priority: "med", notes: "", category: "other" });

  const entity = ENTITIES.find((e) => e.id === activeEntity);
  const entityTasks = tasks.filter((t) => t.entityId === activeEntity);
  const visibleTasks = entityTasks
    .filter((t) => (showDone ? true : t.status === "open"))
    .sort((a, b) => {
      if (a.status !== b.status) return a.status === "open" ? -1 : 1;
      if (!a.dueDate && !b.dueDate) return 0;
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return a.dueDate.localeCompare(b.dueDate);
    });

  const grouped = TASK_CATEGORIES.map((cat) => ({
    cat,
    items: visibleTasks.filter((t) => (t.category || "other") === cat.id),
  })).filter((g) => g.items.length > 0);

  const counts = {};
  ENTITIES.forEach((e) => {
    counts[e.id] = tasks.filter((t) => t.entityId === e.id && t.status === "open").length;
  });
  const overdueCount = tasks.filter((t) => t.status === "open" && t.dueDate && daysUntil(t.dueDate) < 0).length;
  const dueSoonCount = tasks.filter((t) => t.status === "open" && t.dueDate && daysUntil(t.dueDate) >= 0 && daysUntil(t.dueDate) <= 7).length;
  const openCount = tasks.filter((t) => t.status === "open").length;

  function addTask(e) {
    e.preventDefault();
    if (!form.title.trim()) return;
    updateTasks([
      ...tasks,
      {
        id: uid(),
        entityId: activeEntity,
        category: form.category,
        title: form.title.trim(),
        dueDate: form.dueDate || null,
        priority: form.priority,
        notes: form.notes.trim(),
        status: "open",
        createdAt: todayISO(),
      },
    ]);
    setForm({ title: "", dueDate: "", priority: "med", notes: "", category: "other" });
    setFormOpen(false);
  }
  function toggleStatus(id) {
    updateTasks(tasks.map((t) => (t.id === id ? { ...t, status: t.status === "open" ? "done" : "open" } : t)));
  }
  function deleteTask(id) {
    updateTasks(tasks.filter((t) => t.id !== id));
  }

  return (
    <div>
      <div style={styles.statBarRow}>
        <Stat label="Open" value={openCount} tone="normal" />
        <Stat label="Due ≤7d" value={dueSoonCount} tone={dueSoonCount ? "soon" : "normal"} />
        <Stat label="Overdue" value={overdueCount} tone={overdueCount ? "overdue" : "normal"} />
      </div>
      <EntityTabs entities={ENTITIES} active={activeEntity} onChange={setActiveEntity} counts={counts} />
      <main style={styles.panel}>
        <div style={styles.panelHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <entity.Icon size={16} color={entity.color} />
            <span style={styles.entityName}>{entity.name}</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <label style={styles.checkboxLabel}>
              <input type="checkbox" checked={showDone} onChange={(e) => setShowDone(e.target.checked)} style={{ marginRight: 6, accentColor: entity.color }} />
              Show done
            </label>
            <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color }} onClick={() => { setFormOpen((f) => !f); setBulkOpen(false); }}>
              {formOpen ? "Cancel" : "+ Add task"}
            </button>
            <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color }} onClick={() => { setBulkOpen((b) => !b); setFormOpen(false); }}>
              {bulkOpen ? "Cancel" : "Bulk add"}
            </button>
          </div>
        </div>

        {formOpen && (
          <form onSubmit={addTask} style={styles.form}>
            <input autoFocus placeholder="Task title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} style={styles.input} />
            <div style={{ display: "flex", gap: 10 }}>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} style={{ ...styles.input, flex: 1 }}>
                {TASK_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>{c.label}</option>
                ))}
              </select>
              <input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} style={{ ...styles.input, flex: 1 }}>
                {PRIORITIES.map((p) => (
                  <option key={p.id} value={p.id}>{p.label} priority</option>
                ))}
              </select>
            </div>
            <textarea placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} style={{ ...styles.input, minHeight: 56, resize: "vertical" }} />
            <button type="submit" className="ic-btn" style={{ ...styles.saveBtn, background: entity.color }}>Save task</button>
          </form>
        )}

        {bulkOpen && (
          <BulkAddPanel
            fields={[
              { key: "title", label: "Title", required: true },
              { key: "category", label: "Category (intake/entity/other)" },
              { key: "duedate", label: "Due date (YYYY-MM-DD)" },
              { key: "priority", label: "Priority (high/med/low)" },
              { key: "notes", label: "Notes" },
            ]}
            example="Call vendor, other, 2025-09-10, high, Confirm invoice details"
            itemLabel="task"
            accentColor={entity.color}
            onAdd={(rows) => {
              const validCategories = TASK_CATEGORIES.map((c) => c.id);
              const validPriorities = PRIORITIES.map((p) => p.id);
              const newItems = rows.map((r) => ({
                id: uid(),
                entityId: activeEntity,
                category: validCategories.includes((r.category || "").toLowerCase()) ? r.category.toLowerCase() : "other",
                title: r.title.trim(),
                dueDate: (r.duedate || "").trim() || null,
                priority: validPriorities.includes((r.priority || "").toLowerCase()) ? r.priority.toLowerCase() : "med",
                notes: (r.notes || "").trim(),
                status: "open",
                createdAt: todayISO(),
              }));
              updateTasks([...tasks, ...newItems]);
              setBulkOpen(false);
            }}
          />
        )}

        {grouped.length === 0 ? (
          <div style={styles.empty}>
            <Inbox size={28} color="#DCCFA8" style={{ display: "block", margin: "0 auto 8px" }} />
            No {showDone ? "" : "open "}tasks for {entity.short}. Add one to start the ledger.
          </div>
        ) : (
          <div>
            {grouped.map(({ cat, items }) => (
              <div key={cat.id} style={{ marginBottom: 8 }}>
                <div style={styles.categoryHeader}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: cat.color, display: "inline-block" }} />
                  {cat.label}
                  <span style={styles.categoryCount}>{items.length}</span>
                </div>
                <div>
                  {items.map((t) => {
                    const due = dueLabel(t.dueDate);
                    return (
                      <div key={t.id} className="ic-row" style={styles.bulletRow}>
                        <button onClick={() => toggleStatus(t.id)} aria-label="Toggle status" style={{ ...styles.checkCircle, borderColor: t.status === "done" ? "#5C8A6C" : entity.color, background: t.status === "done" ? "#5C8A6C" : "transparent" }}>
                          {t.status === "done" ? "✓" : ""}
                        </button>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ ...styles.taskTitle, textDecoration: t.status === "done" ? "line-through" : "none", color: t.status === "done" ? "#A8987A" : "#3A2F1E" }}>{t.title}</div>
                          {t.notes && <div style={styles.taskNotes}>{t.notes}</div>}
                        </div>
                        <span style={{ ...styles.priorityTag, opacity: t.priority === "high" ? 1 : 0.55 }}>{PRIORITIES.find((p) => p.id === t.priority)?.label}</span>
                        <span style={{ ...styles.dueTag, color: toneColor(due.tone) }}>{due.text}</span>
                        <button onClick={() => deleteTask(t.id)} aria-label="Delete task" style={styles.deleteBtn}>×</button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function CRMModule({ contacts, updateContacts }) {
  const [activeEntity, setActiveEntity] = useState("krt");
  const [formOpen, setFormOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [form, setForm] = useState({ name: "", company: "", phone: "", email: "", value: "", stage: "new", nextFollowUp: "", notes: "" });

  const entity = CRM_ENTITIES.find((e) => e.id === activeEntity);
  const entityContacts = contacts
    .filter((c) => c.entityId === activeEntity)
    .sort((a, b) => (a.nextFollowUp || "9999").localeCompare(b.nextFollowUp || "9999"));

  const counts = {};
  CRM_ENTITIES.forEach((e) => {
    counts[e.id] = contacts.filter((c) => c.entityId === e.id && c.stage !== "won" && c.stage !== "lost").length;
  });

  const openPipeline = contacts.filter((c) => c.entityId === activeEntity && c.stage !== "won" && c.stage !== "lost");
  const pipelineValue = openPipeline.reduce((sum, c) => sum + (Number(c.value) || 0), 0);
  const wonCount = contacts.filter((c) => c.entityId === activeEntity && c.stage === "won").length;

  function addContact(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    updateContacts([
      ...contacts,
      { id: uid(), entityId: activeEntity, ...form, name: form.name.trim(), createdAt: todayISO() },
    ]);
    setForm({ name: "", company: "", phone: "", email: "", value: "", stage: "new", nextFollowUp: "", notes: "" });
    setFormOpen(false);
  }
  function setStage(id, stage) {
    updateContacts(contacts.map((c) => (c.id === id ? { ...c, stage } : c)));
  }
  function deleteContact(id) {
    updateContacts(contacts.filter((c) => c.id !== id));
  }

  return (
    <div>
      <div style={styles.statBarRow}>
        <Stat label="Open leads" value={openPipeline.length} tone="normal" />
        <Stat label="Pipeline value" value={money(pipelineValue)} tone="normal" />
        <Stat label="Won" value={wonCount} tone="normal" />
      </div>
      <EntityTabs entities={CRM_ENTITIES} active={activeEntity} onChange={setActiveEntity} counts={counts} />
      <main style={styles.panel}>
        <div style={styles.panelHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <entity.Icon size={16} color={entity.color} />
            <span style={styles.entityName}>{entity.name} — leads &amp; clients</span>
          </div>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color }} onClick={() => { setFormOpen((f) => !f); setBulkOpen(false); }}>
            {formOpen ? "Cancel" : "+ Add contact"}
          </button>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color, marginLeft: 8 }} onClick={() => { setBulkOpen((b) => !b); setFormOpen(false); }}>
            {bulkOpen ? "Cancel" : "Bulk add"}
          </button>
        </div>

        {formOpen && (
          <form onSubmit={addContact} style={styles.form}>
            <div style={{ display: "flex", gap: 10 }}>
              <input autoFocus placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <input placeholder="Company (optional)" value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Est. value ($)" type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <select value={form.stage} onChange={(e) => setForm({ ...form, stage: e.target.value })} style={{ ...styles.input, flex: 1 }}>
                {STAGES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
              </select>
              <input type="date" value={form.nextFollowUp} onChange={(e) => setForm({ ...form, nextFollowUp: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <textarea placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} style={{ ...styles.input, minHeight: 56, resize: "vertical" }} />
            <button type="submit" className="ic-btn" style={{ ...styles.saveBtn, background: entity.color }}>Save contact</button>
          </form>
        )}

        {bulkOpen && (
          <BulkAddPanel
            fields={[
              { key: "name", label: "Name", required: true },
              { key: "company", label: "Company" },
              { key: "phone", label: "Phone" },
              { key: "email", label: "Email" },
              { key: "value", label: "Est. value" },
              { key: "stage", label: "Stage (new/contacted/qualified/proposal/won/lost)" },
              { key: "nextfollowup", label: "Next follow-up (YYYY-MM-DD)" },
              { key: "notes", label: "Notes" },
            ]}
            example="Jane Doe, Acme Co, (555) 123-4567, jane@acme.com, 5000, new, 2025-09-15, Referred by John"
            itemLabel="contact"
            accentColor={entity.color}
            onAdd={(rows) => {
              const validStages = STAGES.map((s) => s.id);
              const newItems = rows.map((r) => ({
                id: uid(),
                entityId: activeEntity,
                name: r.name.trim(),
                company: (r.company || "").trim(),
                phone: (r.phone || "").trim(),
                email: (r.email || "").trim(),
                value: (r.value || "").trim(),
                stage: validStages.includes((r.stage || "").toLowerCase()) ? r.stage.toLowerCase() : "new",
                nextFollowUp: (r.nextfollowup || "").trim(),
                notes: (r.notes || "").trim(),
                createdAt: todayISO(),
              }));
              updateContacts([...contacts, ...newItems]);
              setBulkOpen(false);
            }}
          />
        )}

        {entityContacts.length === 0 ? (
          <div style={styles.empty}>
            <Users size={28} color="#DCCFA8" style={{ display: "block", margin: "0 auto 8px" }} />
            No contacts for {entity.short} yet. Add your first lead.
          </div>
        ) : (
          <div>
            {entityContacts.map((c) => {
              const stage = STAGES.find((s) => s.id === c.stage);
              const follow = dueLabel(c.nextFollowUp, "past due");
              return (
                <div key={c.id} className="ic-row" style={styles.row}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={styles.taskTitle}>{c.name}{c.company ? ` · ${c.company}` : ""}</div>
                    <div style={styles.taskNotes}>{[c.phone, c.email].filter(Boolean).join(" · ") || c.notes || ""}</div>
                  </div>
                  {c.value ? <span style={styles.priorityTag}>{money(c.value)}</span> : null}
                  <span style={{ ...styles.dueTag, color: toneColor(follow.tone), minWidth: 110 }}>{c.nextFollowUp ? follow.text : "No follow-up"}</span>
                  <select value={c.stage} onChange={(e) => setStage(c.id, e.target.value)} style={{ ...styles.stageSelect, borderColor: stage.color, color: stage.color }}>
                    {STAGES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
                  </select>
                  <button onClick={() => deleteContact(c.id)} aria-label="Delete contact" style={styles.deleteBtn}>×</button>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

function FinancialsModule({ entries, updateEntries }) {
  const [activeEntity, setActiveEntity] = useState("krt");
  const [formOpen, setFormOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [form, setForm] = useState({ type: "revenue", amount: "", date: todayISO(), category: "", note: "" });

  const entity = CRM_ENTITIES.find((e) => e.id === activeEntity);
  const entityEntries = entries.filter((e) => e.entityId === activeEntity).sort((a, b) => b.date.localeCompare(a.date));
  const revenue = entityEntries.filter((e) => e.type === "revenue").reduce((s, e) => s + Number(e.amount || 0), 0);
  const expenses = entityEntries.filter((e) => e.type === "expense").reduce((s, e) => s + Number(e.amount || 0), 0);
  const net = revenue - expenses;

  const counts = {};
  CRM_ENTITIES.forEach((e) => {
    counts[e.id] = entries.filter((en) => en.entityId === e.id).length;
  });

  function addEntry(e) {
    e.preventDefault();
    if (!form.amount || isNaN(Number(form.amount))) return;
    updateEntries([...entries, { id: uid(), entityId: activeEntity, ...form, amount: Number(form.amount) }]);
    setForm({ type: "revenue", amount: "", date: todayISO(), category: "", note: "" });
    setFormOpen(false);
  }
  function deleteEntry(id) {
    updateEntries(entries.filter((e) => e.id !== id));
  }

  return (
    <div>
      <div style={styles.statBarRow}>
        <Stat label="Revenue" value={money(revenue)} tone="normal" />
        <Stat label="Expenses" value={money(expenses)} tone="normal" />
        <Stat label="Net" value={money(net)} tone={net < 0 ? "overdue" : "normal"} />
      </div>
      <EntityTabs entities={CRM_ENTITIES} active={activeEntity} onChange={setActiveEntity} counts={counts} />
      <main style={styles.panel}>
        <div style={styles.panelHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <entity.Icon size={16} color={entity.color} />
            <span style={styles.entityName}>{entity.name} — ledger</span>
          </div>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color }} onClick={() => { setFormOpen((f) => !f); setBulkOpen(false); }}>
            {formOpen ? "Cancel" : "+ Add entry"}
          </button>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: entity.color, color: entity.color, marginLeft: 8 }} onClick={() => { setBulkOpen((b) => !b); setFormOpen(false); }}>
            {bulkOpen ? "Cancel" : "Bulk add"}
          </button>
        </div>

        {formOpen && (
          <form onSubmit={addEntry} style={styles.form}>
            <div style={{ display: "flex", gap: 10 }}>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} style={{ ...styles.input, flex: 1 }}>
                <option value="revenue">Revenue</option>
                <option value="expense">Expense</option>
              </select>
              <input placeholder="Amount ($)" type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Category (e.g. Premiums, Rent)" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <input placeholder="Note (optional)" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <button type="submit" className="ic-btn" style={{ ...styles.saveBtn, background: entity.color }}>Save entry</button>
          </form>
        )}

        {bulkOpen && (
          <BulkAddPanel
            fields={[
              { key: "type", label: "Type (revenue/expense)", required: true },
              { key: "amount", label: "Amount", required: true },
              { key: "date", label: "Date (YYYY-MM-DD)" },
              { key: "category", label: "Category" },
              { key: "note", label: "Note" },
            ]}
            example="expense, 450, 2025-09-01, Rent, September office rent"
            itemLabel="entry"
            accentColor={entity.color}
            onAdd={(rows) => {
              const newItems = rows
                .map((r) => ({
                  id: uid(),
                  entityId: activeEntity,
                  type: (r.type || "").toLowerCase() === "expense" ? "expense" : "revenue",
                  amount: Number(r.amount) || 0,
                  date: (r.date || "").trim() || todayISO(),
                  category: (r.category || "").trim(),
                  note: (r.note || "").trim(),
                }))
                .filter((r) => r.amount > 0);
              updateEntries([...entries, ...newItems]);
              setBulkOpen(false);
            }}
          />
        )}

        {entityEntries.length === 0 ? (
          <div style={styles.empty}>
            <Receipt size={28} color="#DCCFA8" style={{ display: "block", margin: "0 auto 8px" }} />
            No entries for {entity.short} yet. Log your first revenue or expense.
          </div>
        ) : (
          <div>
            {entityEntries.map((en) => (
              <div key={en.id} className="ic-row" style={styles.row}>
                <span style={{ ...styles.moneyTag, color: en.type === "revenue" ? "#5C8A6C" : "#B5654F" }}>
                  {en.type === "revenue" ? "+" : "−"}{money(en.amount)}
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={styles.taskTitle}>{en.category || (en.type === "revenue" ? "Revenue" : "Expense")}</div>
                  {en.note && <div style={styles.taskNotes}>{en.note}</div>}
                </div>
                <span style={styles.dueTag}>{new Date(en.date + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
                <button onClick={() => deleteEntry(en.id)} aria-label="Delete entry" style={styles.deleteBtn}>×</button>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function TurnaroundModule({ scenes, updateScenes }) {
  const [formOpen, setFormOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [form, setForm] = useState({ sceneNumber: "", title: "", location: "", characters: "", status: "outline", notes: "" });

  const sorted = [...scenes].sort((a, b) => (Number(a.sceneNumber) || 0) - (Number(b.sceneNumber) || 0));
  const shotCount = scenes.filter((s) => s.status === "shot").length;
  const lockedCount = scenes.filter((s) => s.status === "locked").length;

  function addScene(e) {
    e.preventDefault();
    if (!form.title.trim()) return;
    updateScenes([...scenes, { id: uid(), ...form, title: form.title.trim() }]);
    setForm({ sceneNumber: "", title: "", location: "", characters: "", status: "outline", notes: "" });
    setFormOpen(false);
  }
  function setStatus(id, status) {
    updateScenes(scenes.map((s) => (s.id === id ? { ...s, status } : s)));
  }
  function deleteScene(id) {
    updateScenes(scenes.filter((s) => s.id !== id));
  }

  return (
    <div>
      <div style={styles.statBarRow}>
        <Stat label="Scenes" value={scenes.length} tone="normal" />
        <Stat label="Locked" value={lockedCount} tone="normal" />
        <Stat label="Shot" value={shotCount} tone="normal" />
      </div>
      <main style={{ ...styles.panel, margin: "16px 24px 0", borderRadius: 8 }}>
        <div style={styles.panelHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Clapperboard size={16} color="#B08D57" />
            <span style={styles.entityName}>Turnaround — production tracker</span>
          </div>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: "#B08D57", color: "#B08D57" }} onClick={() => { setFormOpen((f) => !f); setBulkOpen(false); }}>
            {formOpen ? "Cancel" : "+ Add scene"}
          </button>
          <button className="ic-btn" style={{ ...styles.addBtn, borderColor: "#B08D57", color: "#B08D57", marginLeft: 8 }} onClick={() => { setBulkOpen((b) => !b); setFormOpen(false); }}>
            {bulkOpen ? "Cancel" : "Bulk add"}
          </button>
        </div>

        {formOpen && (
          <form onSubmit={addScene} style={styles.form}>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Scene #" value={form.sceneNumber} onChange={(e) => setForm({ ...form, sceneNumber: e.target.value })} style={{ ...styles.input, maxWidth: 90 }} />
              <input placeholder="Scene title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} style={{ ...styles.input, flex: 2 }} />
              <input placeholder="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} style={{ ...styles.input, flex: 1 }} />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <input placeholder="Characters (comma separated)" value={form.characters} onChange={(e) => setForm({ ...form, characters: e.target.value })} style={{ ...styles.input, flex: 1 }} />
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })} style={{ ...styles.input, flex: 1 }}>
                {SCENE_STATUSES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
              </select>
            </div>
            <textarea placeholder="Notes (optional)" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} style={{ ...styles.input, minHeight: 56, resize: "vertical" }} />
            <button type="submit" className="ic-btn" style={{ ...styles.saveBtn, background: "#B08D57" }}>Save scene</button>
          </form>
        )}

        {bulkOpen && (
          <BulkAddPanel
            fields={[
              { key: "scenenumber", label: "Scene #" },
              { key: "title", label: "Title", required: true },
              { key: "location", label: "Location" },
              { key: "characters", label: "Characters" },
              { key: "status", label: "Status (outline/draft/revised/locked/shot)" },
              { key: "notes", label: "Notes" },
            ]}
            example="12, Diner confrontation, Roadside Diner, Maya & Jonas, draft, Needs rewrite on ending"
            itemLabel="scene"
            accentColor="#B08D57"
            onAdd={(rows) => {
              const validStatuses = SCENE_STATUSES.map((s) => s.id);
              const newItems = rows.map((r) => ({
                id: uid(),
                sceneNumber: (r.scenenumber || "").trim(),
                title: r.title.trim(),
                location: (r.location || "").trim(),
                characters: (r.characters || "").trim(),
                status: validStatuses.includes((r.status || "").toLowerCase()) ? r.status.toLowerCase() : "outline",
                notes: (r.notes || "").trim(),
              }));
              updateScenes([...scenes, ...newItems]);
              setBulkOpen(false);
            }}
          />
        )}

        {sorted.length === 0 ? (
          <div style={styles.empty}>
            <Film size={28} color="#DCCFA8" style={{ display: "block", margin: "0 auto 8px" }} />
            No scenes logged yet. Add the first one from the script.
          </div>
        ) : (
          <div>
            {sorted.map((s) => {
              const status = SCENE_STATUSES.find((st) => st.id === s.status);
              return (
                <div key={s.id} className="ic-row" style={styles.row}>
                  <span style={styles.sceneNum}>{s.sceneNumber || "—"}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={styles.taskTitle}>{s.title}{s.location ? ` · ${s.location}` : ""}</div>
                    <div style={styles.taskNotes}>{s.characters || s.notes || ""}</div>
                  </div>
                  <select value={s.status} onChange={(e) => setStatus(s.id, e.target.value)} style={{ ...styles.stageSelect, borderColor: status.color, color: status.color }}>
                    {SCENE_STATUSES.map((st) => <option key={st.id} value={st.id}>{st.label}</option>)}
                  </select>
                  <button onClick={() => deleteScene(s.id)} aria-label="Delete scene" style={styles.deleteBtn}>×</button>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

const styles = {
  app: {
    display: "flex",
    flexDirection: "column",
    background: "#FAF3E4",
    minHeight: 560,
    fontFamily: "Inter, sans-serif",
    padding: "0 0 24px",
    borderRadius: 10,
    overflow: "hidden",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    padding: "24px 24px 0",
    borderBottom: "1px solid #E8DDC0",
  },
  wordmark: { fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 22, letterSpacing: "0.08em", color: "#3A2F1E" },
  subtitle: { fontSize: 12, color: "#8A7A5C", marginTop: 2, letterSpacing: "0.02em" },
  moduleNav: { display: "flex", gap: 20 },
  moduleBtn: {
    background: "transparent",
    border: "none",
    fontFamily: "'Space Grotesk', sans-serif",
    fontSize: 13,
    fontWeight: 500,
    padding: "0 2px 12px",
    cursor: "pointer",
  },
  statBarRow: { display: "flex", gap: 24, padding: "18px 24px 0" },
  stat: { textAlign: "left" },
  statValue: { fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 500, lineHeight: 1 },
  statLabel: { fontSize: 10, color: "#A8987A", marginTop: 4, textTransform: "uppercase", letterSpacing: "0.06em" },
  tabRow: { display: "flex", gap: 2, padding: "16px 24px 0" },
  tab: {
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: 500,
    fontSize: 13,
    padding: "10px 16px",
    borderLeft: "none",
    borderRight: "none",
    borderBottom: "none",
    borderRadius: "6px 6px 0 0",
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    gap: 8,
  },
  tabCount: { fontFamily: "'JetBrains Mono', monospace", fontSize: 11 },
  panel: { background: "#FFFCF3", margin: "0 24px", borderRadius: "0 8px 8px 8px", padding: "20px 22px", flex: 1 },
  panelHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 12 },
  entityName: { fontFamily: "'Space Grotesk', sans-serif", fontSize: 16, fontWeight: 500, color: "#3A2F1E" },
  checkboxLabel: { fontSize: 12, color: "#8A7A5C", display: "flex", alignItems: "center" },
  addBtn: { background: "transparent", border: "1px solid", borderRadius: 6, padding: "7px 14px", fontSize: 12, fontWeight: 500, cursor: "pointer", fontFamily: "Inter, sans-serif" },
  form: { display: "flex", flexDirection: "column", gap: 10, background: "#F3EAD3", borderRadius: 8, padding: 16, marginBottom: 16 },
  bulkHint: { fontSize: 12, color: "#8A7A5C", lineHeight: 1.5 },
  bulkExample: { fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#3A2F1E", background: "#FFFFFF", border: "1px solid #DCCFA8", borderRadius: 6, padding: "8px 10px", marginTop: 6, whiteSpace: "pre-wrap", wordBreak: "break-word" },
  bulkFeedback: { fontSize: 12, color: "#5C8A6C", fontWeight: 500 },
  input: { background: "#FFFFFF", border: "1px solid #DCCFA8", borderRadius: 6, color: "#3A2F1E", padding: "9px 12px", fontSize: 13, outline: "none", width: "100%" },
  saveBtn: { border: "none", borderRadius: 6, padding: "10px 16px", fontSize: 13, fontWeight: 500, color: "#1C1E22", cursor: "pointer", fontFamily: "Inter, sans-serif", alignSelf: "flex-start" },
  empty: { color: "#A8987A", fontSize: 13, padding: "32px 4px", fontStyle: "italic", textAlign: "center" },
  row: { display: "flex", alignItems: "center", gap: 12, padding: "12px 8px", borderBottom: "1px solid #EFE6CE", borderRadius: 6 },
  categoryHeader: { display: "flex", alignItems: "center", gap: 8, fontFamily: "'Space Grotesk', sans-serif", fontSize: 12, fontWeight: 600, color: "#3A2F1E", textTransform: "uppercase", letterSpacing: "0.05em", padding: "10px 8px 8px", borderTop: "1px solid #EFE6CE" },
  categoryCount: { fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#A8987A", marginLeft: "auto", textTransform: "none", letterSpacing: 0 },
  bulletRow: { display: "flex", alignItems: "center", gap: 12, padding: "10px 8px 10px 24px", borderBottom: "1px solid #F3ECDA", borderRadius: 6 },
  checkCircle: { width: 20, height: 20, minWidth: 20, borderRadius: "50%", border: "1.5px solid", background: "transparent", cursor: "pointer", color: "#1C1E22", fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  taskTitle: { fontSize: 14, fontWeight: 500, color: "#3A2F1E" },
  taskNotes: { fontSize: 12, color: "#8A7A5C", marginTop: 2 },
  priorityTag: { fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#8A7A5C", textTransform: "uppercase", letterSpacing: "0.04em", minWidth: 60, textAlign: "right" },
  moneyTag: { fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 500, minWidth: 90 },
  dueTag: { fontFamily: "'JetBrains Mono', monospace", fontSize: 12, minWidth: 130, textAlign: "right", color: "#8A7A5C" },
  stageSelect: { background: "#FFFFFF", border: "1px solid", borderRadius: 6, padding: "6px 10px", fontSize: 11, fontFamily: "'JetBrains Mono', monospace", cursor: "pointer" },
  sceneNum: { fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: "#B08D57", minWidth: 28, textAlign: "center" },
  deleteBtn: { background: "transparent", border: "none", color: "#A8987A", fontSize: 18, cursor: "pointer", padding: "0 4px", lineHeight: 1 },
  footer: { fontSize: 11, color: "#A8987A", padding: "16px 24px 0", fontFamily: "'JetBrains Mono', monospace" },
};
